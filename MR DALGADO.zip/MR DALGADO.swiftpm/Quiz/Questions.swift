import Foundation

struct Questions {
    var Question: String
    var Option1 : String
    var Option2 : String
    var Option3 : String
    var Option4 : String
    var Answer : Int
    var plainTextAnswer : String

}
